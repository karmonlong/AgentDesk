# 🤖 AgentDesk - 资管智能体工作台

基于 **LangGraph 1.0** 构建的智能协作平台，专为资管行业打造的多智能体工作台。

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![LangGraph](https://img.shields.io/badge/LangGraph-1.0+-orange.svg)](https://langchain-ai.github.io/langgraph/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.115+-green.svg)](https://fastapi.tiangolo.com/)

## ✨ 功能特性

### 🎯 核心功能
- **📄 文档处理**
  - 文档总结（自动生成摘要和要点）
  - 内容生成（基于文档撰写报告、邮件）
  - 格式转换（转换为 Markdown、结构化数据）
  - 表格提取（从 PDF、Excel 提取表格）
  - 要点提取（提取关键信息、行动项）
  - 深度分析（论证、逻辑、立场分析）

- **🔍 知识管理** ⭐ 新功能
  - 向量检索（基于 ChromaDB 的语义搜索）
  - 智能问答（RAG 增强检索生成）
  - 多文档对比（跨文档关联分析）
  - 知识库构建（自动向量化和索引）
  - 精准引用（所有答案提供原文来源）

- **🎙️ 播客生成** ⭐ 新功能
  - PDF 转播客（基于 Open NotebookLM）
  - 智能对话（双人主持风格）
  - 多语言支持（13 种语言）
  - 高质量语音（MeloTTS / Suno Bark）
  - 一键导出（MP3 格式）

### 🛠️ 技术特性
- **基于 LangGraph 1.0**: 持久化状态管理、人工审核、错误恢复
- **向量检索引擎**: ChromaDB + Google Gemini Embeddings
- **RAG 增强**: 检索增强生成，提供可追溯的智能问答
- **支持多种格式**: TXT, PDF, DOCX, XLSX, CSV, MD, JSON
- **多智能体协作**: 8 个专业智能体协同工作
- **Web 界面**: 直观的操作界面，拖拽上传
- **状态持久化**: 自动保存检查点，支持暂停/恢复
- **批量处理**: 支持多个文档批量处理
- **生产就绪**: 完整的错误处理和日志系统

## 🚀 快速开始

### 前置要求

- Python 3.10+
- Gemini (Google AI) API 密钥

### 1. 克隆项目

```bash
git clone <repository-url>
cd office-assistant
```

### 2. 配置环境

```bash
# 1. 复制配置文件
cp .env.example .env

# 2. 编辑 .env 文件，填入你的 Gemini API 密钥
nano .env

# .env 文件内容示例:
GEMINI_API_KEY=AIzaSy...
GEMINI_MODEL=gemini-1.5-flash-latest
```

### 3. 安装依赖

#### 方式一：使用 Makefile（推荐）

```bash
# 自动创建虚拟环境并安装依赖
make install

# 如果未设置 GEMINI_API_KEY，会提示你配置
# 请将 .env 文件中的 GEMINI_API_KEY 替换为你的真实密钥
```

#### 方式二：手动安装

```bash
# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate    # Windows

# 安装依赖
pip install -r requirements.txt
```

### 4. 启动服务

#### 方式一：生产模式

```bash
make run

# 或直接运行
python app.py
```

访问 http://localhost:8000

#### 方式二：开发模式（热重载）

```bash
make dev

# 或直接运行
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```

访问 http://localhost:8000

## 📖 使用说明

### Web 界面操作

1. **上传文档**
   - 点击"选择文件"，上传你的文档
   - 支持的格式：TXT, PDF, DOCX, XLSX, CSV, MD, JSON
   - 文件大小限制：50MB

2. **选择操作类型**
   - **总结文档**: 提取核心要点，生成简洁摘要
   - **生成内容**: 基于文档撰写报告、邮件等
   - **格式转换**: 转换为 Markdown 等结构化格式
   - **提取表格**: 提取文档中的表格和数据
   - **提取要点**: 提取关键信息、日期、金额等
   - **深度分析**: 分析论证逻辑和作者立场

3. **添加额外指示**（可选）
   - 例如："生成邮件格式"、"重点突出数据指标"、"中英文对照"

4. **开始处理**
   - 点击"开始处理"按钮
   - 实时查看处理进度
   - 处理完成后预览结果

5. **下载结果**
   - 点击"下载结果"保存处理后的文件
   - 所有结果也会自动保存在 `uploads/` 目录

### 命令行模式

```bash
make run-cli

# 或直接运行
python -m graph.document_graph
```

按提示输入文件路径和操作类型。

### API 调用

```bash
# 上传并处理文档
curl -X POST -F "file=@document.pdf" \
  -F "operation=summarize" \
  http://localhost:8000/upload

# 下载结果
curl -O http://localhost:8000/download/{filename}
```

完整的 API 文档：http://localhost:8000/docs

### 🤖 智能体团队

AgentDesk 配备了 8 个专业智能体，协同处理各类任务：

| 智能体 | 角色 | 擅长领域 |
|--------|------|----------|
| 📊 文档分析师 | 信息提取与分析专家 | 文档理解、数据提取、结构分析 |
| ✍️ 内容创作者 | 专业内容撰写专家 | 报告生成、文章撰写、邮件起草 |
| 📈 数据专家 | 数据分析与洞察专家 | 财务分析、数据可视化、趋势预测 |
| ✅ 校对编辑 | 内容质量把控专家 | 语法检查、风格优化、质量提升 |
| 🌐 翻译专家 | 专业翻译与本地化专家 | 中英翻译、术语处理、文化适配 |
| ⚖️ 合规官 | 合规与风险控制专家 | 监管审核、风险识别、政策解读 |
| 📚 知识管理专家 | 文档知识库与检索专家 | 向量检索、智能问答、多文档分析 |
| 🎯 协调者 | 任务分配与协调专家 | 工作流编排、智能体协作、任务管理 |

**使用方式**：
```
# 在对话中 @ 提及智能体
@知识管理专家 AgentDesk 有哪些核心功能？
@内容创作者 根据这份报告写一篇市场分析文章
@数据专家 分析这个季度的财务数据
```

### 🔍 知识管理功能

AgentDesk 提供基于向量检索的智能知识管理：

**功能亮点**：
- ✅ **语义搜索**：理解查询意图，不只是关键词匹配
- ✅ **智能问答**：基于 RAG 技术，提供准确且可追溯的答案
- ✅ **多文档分析**：跨文档关联分析和对比
- ✅ **引用来源**：所有答案都标注原文出处
- ✅ **持久化存储**：向量数据库自动持久化

**API 示例**：
```bash
# 添加文档到知识库
curl -X POST -F "file=@document.pdf" \
  http://localhost:8000/api/knowledge/add

# 搜索知识库
curl -X POST \
  -d "query=AgentDesk的核心功能" \
  -d "k=5" \
  http://localhost:8000/api/knowledge/search

# 列出知识库文档
curl http://localhost:8000/api/knowledge/list
```

**使用场景**：
- 📖 构建企业知识库
- 💬 智能问答系统
- 🔎 文档检索和对比
- 📊 多源信息综合

详细使用说明请参考：[知识管理功能指南](./docs/KNOWLEDGE_MANAGEMENT.md)

### 🎙️ 播客生成功能（Open NotebookLM）

AgentDesk 集成了 **Open NotebookLM** 开源项目，可以将 PDF 文档转换为播客音频。

**功能亮点**：
- ✅ **PDF 转播客**：上传 PDF，自动生成双人对话播客
- ✅ **智能理解**：使用 Llama 3.3 70B 理解文档内容
- ✅ **自然对话**：模拟两位主持人的真实讨论
- ✅ **多语言**：支持中文、英文等 13 种语言
- ✅ **高质量**：专业级语音合成（MeloTTS/Bark）

**快速启动**：
```bash
# 1. 配置 API 密钥（首次使用）
cd open-notebooklm
cp .env.example .env
nano .env  # 设置 FIREWORKS_API_KEY

# 2. 启动服务
./start.sh

# 3. 访问界面
# http://localhost:7860
```

**使用场景**：
- 📚 学习：将学术论文转为播客，边走边听
- 💼 工作：投资报告转为音频，通勤时间吸收信息
- 📰 新闻：将长文转为播客，高效获取资讯

详细使用说明请参考：[Open NotebookLM 使用指南](./docs/OPEN_NOTEBOOKLM_GUIDE.md)

## 📂 项目结构

```
office-assistant/
├── app.py                      # 主程序（FastAPI Web 服务）
├── graph/
│   ├── __init__.py
│   └── document_graph.py       # LangGraph 工作流定义
├── agents/
│   ├── __init__.py
│   └── document_agent.py       # AI 智能体定义
├── tools/
│   ├── __init__.py
│   ├── file_tools.py           # 文件读写工具（PDF, DOCX, XLSX 等）
│   ├── document_tools.py       # 文档处理工具（摘要、提取、转换）
│   └── vector_store.py         # 向量存储工具（ChromaDB）
├── open-notebooklm/            # Open NotebookLM（播客生成）
│   ├── app.py                  # Gradio 应用主程序
│   ├── start.sh               # 启动脚本
│   └── .env                   # Fireworks AI API 配置
├── static/                     # 静态文件（前端资源）
├── uploads/                    # 上传和结果文件存储
├── chroma_db/                  # 向量数据库存储
├── requirements.txt            # Python 依赖
├── .env.example               # 配置文件模板
├── Makefile                   # 快速启动脚本
└── README.md                  # 项目说明
```

## 🔧 配置说明

### 环境变量

编辑 `.env` 文件：

```bash
# 必需 - Gemini API 配置
GEMINI_API_KEY=your-gemini-api-key-here
GEMINI_MODEL=gemini-1.5-flash-latest

# 可选 - 服务器配置
PORT=8000                         # 服务端口
HOST=0.0.0.0                      # 监听地址 (0.0.0.0 允许外部访问)
MAX_FILE_SIZE_MB=50               # 文件大小限制（MB）

# 可选 - 存储配置
UPLOAD_DIR=uploads                # 上传目录
LOG_LEVEL=INFO                    # 日志级别
```

### Makefile 常用命令

```bash
make help            # 显示所有可用命令
make install         # 安装依赖
make install-dev     # 安装开发依赖

make run             # 启动服务（生产模式）
make dev             # 启动服务（开发模式，带热重载）
make run-cli         # 命令行模式

make test            # 运行测试
make lint            # 代码检查
make format          # 代码格式化

make clean           # 清理临时文件
make clean-all       # 彻底清理（包括上传文件）

make demo            # 运行演示示例
make status          # 检查服务状态
make api-docs        # 打开API文档
```

## 🎓 示例

### 示例 1：总结会议纪要

```bash
# 1. 准备会议纪要文档 (saved as meeting.docx)
# 2. 上传并选择"总结文档"
# 3. 额外指示: "提取行动项和责任人"
# 4. 获取结构化总结
```

### 示例 2：从报告生成邮件

```bash
# 1. 准备数据报告 (saved as report.xlsx)
# 2. 上传并选择"生成内容"
# 3. 额外指示: "撰写发给管理层的邮件，突出关键指标"
# 4. 获取专业邮件草稿
```

### 示例 3：提取表格数据

```bash
# 1. 准备PDF或Excel文档
# 2. 上传并选择"提取表格"
# 3. 下载提取的表格数据（Markdown格式）
```

### 示例 4：批量处理

```python
# 编程批量处理示例
from graph.document_graph import process_document
import os

docs_dir = "./docs"
for filename in os.listdir(docs_dir):
    if filename.endswith(".pdf"):
        file_path = os.path.join(docs_dir, filename)
        result = process_document(file_path, "summarize")
        print(f"处理完成: {filename}")
```

## 🔍 高级特性

### 1. 人工审核

对于长文本或关键操作，系统会自动暂停等待人工审核：

```python
# 在 graph/document_graph.py 中配置
# 当前策略：结果长度 > 3000 字符或生成操作
needs_review = len(result) > 3000 or operation == "generate"
```

### 2. 检查点恢复

LangGraph 自动保存执行状态，支持从失败点恢复：

```python
# 在 process_document() 中配置
config = {"configurable": {"thread_id": "1"}}
```

### 3. 自定义操作

在 `tools/document_tools.py` 中添加新的操作类型：

```python
def get_operation_prompt(operation: str, content: str, instruction: str = "") -> str:
    if operation == "custom":
        return f"Custom operation... {content}"
```

### 4. 集成外部工具

在 `agents/document_agent.py` 中添加自定义工具：

```python
# 添加新的工具函数
def my_custom_tool(arg1, arg2):
    return f"Result: {arg1}, {arg2}"

# 在智能体中使用
tools = [my_custom_tool]
agent = create_react_agent(llm, tools)
```

## 🐛 故障排除

### 问题 1: `ImportError: No module named 'magic'`

**解决方案:**

```bash
# Linux/Ubuntu
sudo apt-get install libmagic1

# macOS
brew install libmagic

# Windows
# 下载并安装 python-magic-bin from PyPI
```

### 问题 2: `Gemini API key not found`

**解决方案:**

```bash
# 检查 .env 文件是否存在
cat .env

# 检查 API key 是否设置
export GEMINI_API_KEY=AIza...
# 或添加到 .env 文件

# 检查配置示例:
grep GEMINI .env.example
```

### 问题 3: `PDF 读取失败`

**解决方案:**

```bash
# 安装 poppler (用于更快的PDF处理)
# Linux/Ubuntu
sudo apt-get install poppler-utils

# macOS
brew install poppler
```

或使用纯 Python 版本（速度较慢但无需额外依赖）。

### 问题 4: `端口被占用`

**解决方案:**

```bash
# 查看占用端口的进程
lsof -i :8000

# 或使用其他端口
PORT=8001 make run
```

## 📚 相关资源

- [LangGraph 官方文档](https://langchain-ai.github.io/langgraph/)
- [LangChain 文档](https://python.langchain.com/docs/)
- [FastAPI 文档](https://fastapi.tiangolo.com/)
- [OpenAI API 文档](https://platform.openai.com/docs/)

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

1. Fork 本项目
2. 创建功能分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 提交 Pull Request

## 📄 许可证

MIT License

## 🙏 致谢

- [LangChain](https://github.com/langchain-ai/langchain) - 强大的 AI 应用框架
- [FastAPI](https://github.com/tiangolo/fastapi) - 现代 Web 框架
- [Google AI](https://ai.google/) - 提供强大的 Gemini 语言模型

---

💡 **提示**: 如果这个项目对你有帮助，请给颗星 ⭐ 支持一下！
